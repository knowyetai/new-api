# @knowyet/sdk

框架无关契约、平台客户端和交互模型。浏览器入口为 @knowyet/sdk/browser。

版本 0.1.0：首期本地验证版本，未经过真实生产平台联调。API 和使用边界见源码仓库 docs/sdk-api.md、docs/implementation-status.md。
